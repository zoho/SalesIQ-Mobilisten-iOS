//
//  NSData+DataConversion.m
//  WebRTCExtras
//
//  Created by Aravindh on 31/07/24.
//

#import <Foundation/Foundation.h>

@implementation NSData (Extensions)

- (int64_t)getInt64AtIndex:(NSInteger)index {
    if (index + sizeof(int64_t) > self.length) {
        return 0;
    }
    int64_t value = 0;
    [self getBytes:&value range:NSMakeRange(index, sizeof(int64_t))];
    return CFSwapInt64BigToHost(value);
}

- (int32_t)getInt32AtIndex:(NSInteger)index {
    if (index + sizeof(int32_t) > self.length) {
        return 0;
    }
    int32_t value = 0;
    [self getBytes:&value range:NSMakeRange(index, sizeof(int32_t))];
    return CFSwapInt32BigToHost(value);
}

- (int16_t)getInt16AtIndex:(NSInteger)index {
    if (index + sizeof(int16_t) > self.length) {
        return 0;
    }
    int16_t value = 0;
    [self getBytes:&value range:NSMakeRange(index, sizeof(int16_t))];
    return CFSwapInt16BigToHost(value);
}

- (int8_t)getInt8AtIndex:(NSInteger)index {
    if (index + sizeof(int8_t) > self.length) {
        return 0;
    }
    int8_t value = 0;
    [self getBytes:&value range:NSMakeRange(index, sizeof(int8_t))];
    return value;
}

- (NSString *)getStringAtIndex:(NSInteger)index length:(NSInteger)length {
    if (index + length > self.length) {
        return nil;
    }
    NSData *subData = [self subdataWithRange:NSMakeRange(index, length)];
    return [[NSString alloc] initWithData:subData encoding:NSUTF8StringEncoding];
}

- (BOOL)isValidRangeForData:(NSData *)data atIndex:(NSUInteger)startIndex length:(NSUInteger)length {
    return startIndex + length <= data.length;
}

- (int32_t)getInt32FromData:(NSData *)data atIndex:(NSUInteger)startIndex {
    if (![self isValidRangeForData:data atIndex:startIndex length:sizeof(int32_t)]) {
        return 0;
    }
    int32_t value;
    [data getBytes:&value range:NSMakeRange(startIndex, sizeof(int32_t))];
    return ntohl(value);
}

- (int16_t)getInt16FromData:(NSData *)data atIndex:(NSUInteger)startIndex {
    if (![self isValidRangeForData:data atIndex:startIndex length:sizeof(int16_t)]) {
        return 0;
    }
    int16_t value;
    [data getBytes:&value range:NSMakeRange(startIndex, sizeof(int16_t))];
    return ntohs(value);
}

- (int8_t)getInt8FromData:(NSData *)data atIndex:(NSUInteger)startIndex {
    if (![self isValidRangeForData:data atIndex:startIndex length:sizeof(int8_t)]) {
        return 0;
    }
    int8_t value;
    [data getBytes:&value range:NSMakeRange(startIndex, sizeof(int8_t))];
    return value;
}

- (NSString *)getStringFromData:(NSData *)data atIndex:(NSUInteger)startIndex length:(NSUInteger)length {
    if (![self isValidRangeForData:data atIndex:startIndex length:length]) {
        return nil;
    }
    NSData *subdata = [data subdataWithRange:NSMakeRange(startIndex, length)];
    NSString *string = [[NSString alloc] initWithData:subdata encoding:NSUTF8StringEncoding];
    return string;
}

- (id)getValueFromData:(NSData *)data atIndex:(NSUInteger)startIndex size:(NSUInteger)size {
    if (startIndex + size > data.length) {
        return nil;
    }
    id value = nil;
    [data getBytes:&value range:NSMakeRange(startIndex, size)];
    return value;
}


@end
