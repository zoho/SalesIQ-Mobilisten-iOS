//
//  MobilistenCallsCore.h
//  MobilistenCallsCore
//
//  Created by Kishore Kumar A on 21/05/25.
//

#import <Foundation/Foundation.h>

//! Project version number for MobilistenCallsCore.
FOUNDATION_EXPORT double MobilistenCallsCoreVersionNumber;

//! Project version string for MobilistenCallsCore.
FOUNDATION_EXPORT const unsigned char MobilistenCallsCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MobilistenCallsCore/PublicHeader.h>


