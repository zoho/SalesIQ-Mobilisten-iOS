//
//  UnexposedHeaders.h
//  LDPEXLibrary
//
//  Created by Balaji Sankar on 06/03/14.
//  Copyright (c) 2014 Balaji Sankar. All rights reserved.
//

#import "LDApiHeaders.h"
#import <Foundation/Foundation.h>

@interface CollaborationApi ()
/**
 init function of the Api
 */
- (id)init2;
@end

@interface ServiceChatApi ()
/**
 init function of the Api.
 */
- (id)init2;
@end

@interface PresenceGroupApi ()
/**
 init function of the Api
 */
- (id)init2;
@end

@interface CustomChatApi ()
/**
 init function of the Api
 */
- (id)init2;
@end


@interface ChatApi ()
/**
 init function of the Api
 */
- (id)init2;
@end
